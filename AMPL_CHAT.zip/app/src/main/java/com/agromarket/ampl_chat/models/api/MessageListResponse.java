package com.agromarket.ampl_chat.models.api;

import java.util.List;

public class MessageListResponse {
    public boolean status;
    public List<ChatMessage> messages;
}

