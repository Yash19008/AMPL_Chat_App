package com.agromarket.ampl_chat.models.api;
public class SendMessageResponse {
    public boolean status;
    public ChatMessage message;
}