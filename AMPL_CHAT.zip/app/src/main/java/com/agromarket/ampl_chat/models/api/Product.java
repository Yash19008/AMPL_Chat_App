package com.agromarket.ampl_chat.models.api;

public class Product {
    public int id;
    public String name;
    public String sale_price;
    public String image;
}
