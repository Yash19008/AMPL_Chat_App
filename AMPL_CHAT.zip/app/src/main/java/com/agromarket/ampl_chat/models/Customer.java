package com.agromarket.ampl_chat.models;

public class Customer {
    public int id;
    public String name;
    public String email;

    public String latest_message;
    public String latest_message_time;
    public int unread_count;
}