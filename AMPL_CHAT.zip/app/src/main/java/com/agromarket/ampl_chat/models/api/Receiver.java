package com.agromarket.ampl_chat.models.api;

public class Receiver {
    public int id;
    public String name;
}
