package com.agromarket.ampl_chat.models.api;

public class UserShort {
    public int id;
    public String name;
    public String profile_photo_path;
}
