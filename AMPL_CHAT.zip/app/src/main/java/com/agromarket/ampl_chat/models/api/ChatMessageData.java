package com.agromarket.ampl_chat.models.api;

public class ChatMessageData {
    public String name;
    public String price;
    public String image;
    public int id;
}
