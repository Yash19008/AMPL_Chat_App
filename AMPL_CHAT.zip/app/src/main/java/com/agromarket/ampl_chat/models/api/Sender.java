package com.agromarket.ampl_chat.models.api;

public class Sender {
    public int id;
    public String name;
}
