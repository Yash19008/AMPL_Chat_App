package com.agromarket.ampl_chat.models.api;

import com.agromarket.ampl_chat.models.Customer;

import java.util.List;

public class CustomerListResponse {
    public boolean status;
    public List<Customer> customers;
}